
## Installation (Python 3)

	git clone https://github.com/hayj/MachineLearning.git
	pip install ./MachineLearning/wm-dist/*.tar.gz

## Usage

See the code to have more information:

	>>> from machinelearning.optimizer import *
	>>> from nlptools.bandit import *
	>>> from nlptools.function import *

